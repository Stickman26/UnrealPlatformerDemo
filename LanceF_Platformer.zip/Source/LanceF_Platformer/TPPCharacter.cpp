// Fill out your copyright notice in the Description page of Project Settings.


#include "TPPCharacter.h"

// Sets default values
ATPPCharacter::ATPPCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	AutoPossessPlayer = EAutoReceiveInput::Player0;

	bUseControllerRotationYaw = false;

	Cam = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	
	Arm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	Arm->AttachTo(RootComponent);
	Arm->TargetArmLength = 300;
	Arm->SetRelativeRotation(FRotator(-25.f, 0.f, 0.f));
	
	/*
	Arm->bEnableCameraLag = true;
	Arm->CameraLagSpeed = 2;
	Arm->CameraLagMaxDistance = 1.5f;

	Arm->bEnableCameraRotationLag = true;
	Arm->CameraRotationLagSpeed = 4;
	Arm->CameraLagMaxTimeStep = 1;
	//*/

	Cam->AttachTo(Arm, USpringArmComponent::SocketName);

	ChargingJump = false;
	JumpBoost = 0.0f;

	CharMovement = GetCharacterMovement();

	if (CharMovement)
	{
		CharMovement->JumpZVelocity = MinimumJumpVelocity;
	}
}

// Called when the game starts or when spawned
void ATPPCharacter::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ATPPCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (ChargingJump)
	{
		if ((JumpBoost + MinimumJumpVelocity) >= MaximumJumpVelocity)
		{
			JumpBoost = MaximumJumpVelocity - MinimumJumpVelocity;
		}
		else
		{
			JumpBoost += DeltaTime * JumpBoostRate;
		}
	}
}

// Called to bind functionality to input
void ATPPCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	InputComponent->BindAxis("Horizontal", this, &ATPPCharacter::HorizontalMove);
	InputComponent->BindAxis("Vertical", this, &ATPPCharacter::VerticalMove);
	InputComponent->BindAxis("LookHorizontal", this, &ATPPCharacter::HorizontalRot);
	InputComponent->BindAxis("LookVertical", this, &ATPPCharacter::VerticalRot);

	InputComponent->BindAction("Jump", IE_Pressed, this, &ATPPCharacter::ChargeJump);
	InputComponent->BindAction("Jump", IE_Released, this, &ATPPCharacter::ReleaseJump);
}

void ATPPCharacter::HorizontalMove(float value)
{
	if (value)
	{
		AddMovementInput(GetActorRightVector(), value);
	}
}

void ATPPCharacter::VerticalMove(float value)
{
	if (value)
	{
		AddMovementInput(GetActorForwardVector(), value);
	}
}

void ATPPCharacter::HorizontalRot(float value)
{
	if (value)
	{
		AddActorLocalRotation(FRotator(0, value, 0));
	}
}

void ATPPCharacter::VerticalRot(float value)
{
	if (value)
	{
		float temp = Arm->GetRelativeRotation().Pitch + value;
		if (temp < 25 && temp > -65)
		{
			Arm->AddLocalRotation(FRotator(value, 0, 0));
		}
	}
}

void ATPPCharacter::ChargeJump()
{
	ChargingJump = true;
}

void ATPPCharacter::ReleaseJump()
{
	ChargingJump = false;
	
	CharMovement->JumpZVelocity = JumpBoost + MinimumJumpVelocity;
	Jump();

	JumpBoost = 0.0f;
}
