// Fill out your copyright notice in the Description page of Project Settings.


#include "PlatformActor.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/StaticMeshComponent.h"
#include "TPPCharacter.h"
#include "Materials/MaterialInterface.h"

APlatformActor::APlatformActor()
{
	
}

void APlatformActor::BeginPlay()
{
	Super::BeginPlay();

	if (IsMoving)
	{
		StartingPosition = GetActorLocation();
	}
	if (DropPlatformEnabled)
	{
		UStaticMeshComponent* Platform = FindComponentByClass<UStaticMeshComponent>();
		UMaterialInterface* Material = Platform->GetMaterial(0);

		PlatformMaterial = UMaterialInstanceDynamic::Create(Material, NULL);
		Platform->SetMaterial(0, PlatformMaterial);

		Platform->OnComponentHit.AddDynamic(this, &APlatformActor::OnHit);

		DropTimeRemaining = DropTimerTotal;
	}
}

void APlatformActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (IsMoving)
	{
		MovePlatform(DeltaTime);
	}
	
	if (DropPlatformEnabled && IsDropping)
	{
		DropPlatform(DeltaTime);
	}
}

void APlatformActor::MovePlatform(float DeltaTime)
{
	FVector CurrentLocation = GetActorLocation();
	if (TargetPosition == 1)
	{
		FVector Direction = EndingPosition - StartingPosition;
		Direction.Normalize();

		CurrentLocation += Direction * MovementSpeed * MovementSpeedModifier * DeltaTime;
		SetActorLocation(CurrentLocation);

		float Distance = FVector::Dist(CurrentLocation, EndingPosition);
		if (Distance <= 100.0f)
		{
			TargetPosition = 0;
		}
	}
	else
	{
		FVector Direction = StartingPosition - EndingPosition;
		Direction.Normalize();

		CurrentLocation += Direction * MovementSpeed * MovementSpeedModifier * DeltaTime;
		SetActorLocation(CurrentLocation);

		float Distance = FVector::Dist(CurrentLocation, StartingPosition);
		if (Distance <= 100.0f)
		{
			TargetPosition = 1;
		}
	}
}

void APlatformActor::DropPlatform(float DeltaTime)
{
	DropTimeRemaining -= DeltaTime;
	PlatformMaterial->SetScalarParameterValue(TEXT("Blend"), (1.0f - (DropTimeRemaining/DropTimerTotal)));

	if (DropTimeRemaining <= 0.0f)
	{
		Destroy();
	}
}

void APlatformActor::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, FVector NormalImpulse, const FHitResult& Hit)
{

	GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Hit"));

	if (OtherActor != this && OtherActor->IsA(ATPPCharacter::StaticClass()))
	{
		IsDropping = true;
	}
}
