// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "LanceF_PlatformerGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class LANCEF_PLATFORMER_API ALanceF_PlatformerGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
