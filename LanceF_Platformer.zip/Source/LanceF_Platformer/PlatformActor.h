// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/StaticMeshActor.h"
#include "PlatformActor.generated.h"

/**
 * 
 */

UCLASS()
class LANCEF_PLATFORMER_API APlatformActor : public AStaticMeshActor
{
	GENERATED_BODY()
	
public:

	APlatformActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Settings|Movement")
		bool IsMoving = false;
	/** 0 = Start Position, 1 = End Position */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Movement")
		int TargetPosition = 1; 
	/** Automatically set as position platform is placed */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Movement")
		FVector StartingPosition = FVector(0.f, 0.f, 0.f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Settings|Movement")
		FVector EndingPosition = FVector(0.f, 0.f, 0.f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Settings|Movement")
		float MovementSpeed = 1.0f;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Movement")
		float MovementSpeedModifier = 100.0f;

	void MovePlatform(float DeltaTime);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Settings|Trap")
		bool DropPlatformEnabled = false;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Trap")
		bool IsDropping = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Settings|Trap")
		float DropTimerTotal = 3.0f;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Trap")
		float DropTimeRemaining;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Platform Settings|Trap")
		class UBoxComponent* CollisionBox;

	void DropPlatform(float DeltaTime);

	UFUNCTION()
		void OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, FVector NormalImpulse, const FHitResult& Hit);

private:
	UPROPERTY()
		class UMaterialInstanceDynamic* PlatformMaterial;

	virtual void Tick(float DeltaTime) override;
};
