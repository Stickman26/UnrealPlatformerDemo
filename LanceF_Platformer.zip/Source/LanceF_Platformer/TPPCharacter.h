// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/InputComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/Character.h"
#include "TPPCharacter.generated.h"

UCLASS()
class LANCEF_PLATFORMER_API ATPPCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ATPPCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Settings")
		float MinimumJumpVelocity = 450.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Settings")
		float MaximumJumpVelocity = 800.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Player Settings")
		float JumpBoostRate = 400.0f;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		float JumpBoost;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

private:
	UPROPERTY()
		UCameraComponent* Cam;
	UPROPERTY()
		USpringArmComponent* Arm;

	void HorizontalMove(float value);
	void VerticalMove(float value);
	void HorizontalRot(float value);
	void VerticalRot(float value);

	void ChargeJump();
	void ReleaseJump();

	UPROPERTY()
		bool ChargingJump;
	UPROPERTY()
		UCharacterMovementComponent* CharMovement;

};
